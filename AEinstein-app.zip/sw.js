// AEinstein service worker — caches the app shell only.
// API calls to OpenAI/Anthropic/Gemini/Azure/Groq always go to the network.
const CACHE_NAME = 'aeinstein-shell-v1';
const SHELL_FILES = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Never intercept calls to AI providers — always hit the network directly.
  const isApiCall = /(openai\.com|anthropic\.com|googleapis\.com|azure\.com|groq\.com)/.test(url.hostname);
  if (isApiCall) return;

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
